<template>
  <div class="rating_page">
    <head-top head-title="选择地址" go-back='true'></head-top>
    <router-link to="/confirmOrder/chooseAddress/addAddress" class="add_icon_footer" >
      <img src="../../../images/add_address.png" height="24" width="24">
      <span>新增收货地址</span>
    </router-link>
    <section id="scroll_section" class="scroll_container">
      <section class="list_cotainer">
        <ul class="deliverable_address">
          <li v-for="(item,index) in addressList" @click.prevent.stop="chooseAddress(item, index)">
            <svg class="choosed_address" :class="{default_address: defaultIndex == index}">
              <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#select"></use>
            </svg>
            <div>
              <header>
                <span>{{item.name}}</span>
                <span>{{item.phone}}</span>
              </header>
              <div class="address_detail ellipsis">
                <p>{{item.address}}</p>
              </div>
            </div>
          </li>
        </ul>
      </section>
    </section>
    <alert-tip v-if="showAlert" @closeTip="showAlert = false" :alertText="alertText"></alert-tip>
    <transition name="router-slid" mode="out-in">
      <router-view></router-view>
    </transition>
  </div>
</template>

<script>
  import headTop from 'src/components/header/head'
  import {mapState, mapMutations} from 'vuex'
  import {getAddress, getAddressList,getaddress} from 'src/service/getData'
  import alertTip from 'src/components/common/alertTip'
  import BScroll from 'better-scroll'
  import Request from 'src/service/api'
  export default {
    data(){
      return{
        addressList: [], //地址列表
        deliverable:null,
        showAlert: false,
        alertText: null,
        current:1,
        size:5,
      }
    },
    created(){
      this.initData();
    },
    mounted(){
//      this.initData();

    },
    components: {
      headTop,
      alertTip,
    },
    props:[],
    computed: {
      ...mapState([
        'userInfo', 'addressIndex', 'newAddress','userToken'
      ]),
      //选择地址
      defaultIndex: function (){
        if (this.addressIndex) {
          return this.addressIndex;
        }

      }
    },
    methods: {
      ...mapMutations([
        'CHOOSE_ADDRESS'
      ]),
      //初始化信息
      async initData(){
//        this.addressList = [];
//        this.deliverable = [];
//        this.deliverdisable = [];
        if (this.userToken) {
          Request.Get('address', {current:this.current,size:this.size,token:this.userToken}).then((res) => {
          this.addressList = res.data;
        })
        }else {
          this.showAlert = true;
          this.alertText = '您还没有登录';
        }
      },
      //选择地址
      chooseAddress(address, index){
        this.CHOOSE_ADDRESS({address, index});
        this.$router.go(-1);
      },
    },
    watch: {
      newAddress: function (value) {
        this.initData();
      },
    }
  }
</script>

<style lang="scss" scoped>
  @import 'src/style/mixin';
  .rating_page{
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #fff;
    z-index: 202;
    padding-top: 1.95rem;
  p, span{
    font-family: Helvetica Neue,Tahoma,Arial;
  }
  }
  .scroll_container{
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    padding-top: 1.95rem;
    overflow-y: auto;
  }
  .list_cotainer{
    padding-bottom: 5rem;
  }
  .add_icon_footer{
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    height: 2.5rem;
    background-color: #fff;
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 204;
  span{
  @include sc(.7rem, $blue);
    margin-left: .3rem;
  }
  }
  .deliverable_address{
    background-color: #fff;
  li{
    display: flex;
    align-items: center;
    border-bottom: 0.025rem solid #f5f5f5;
    padding: .7rem;
    line-height: 1rem;
  .choosed_address{
  @include wh(.8rem, .8rem);
    fill: #4cd964;
    margin-right: .4rem;
    opacity: 0;
  }
  .default_address{
    opacity: 1;
  }
  header{
  @include sc(.7rem, #333);
  span:nth-of-type(1){
    font-size: .8rem;
    font-weight: bold;
  }
  }
  .address_detail{
    width: 100%;
    display: flex;
    align-items: center;
  span{
  @include sc(.5rem, #fff);
    border-radius: .15rem;
    background-color: #ff5722;
    height: .6rem;
    line-height: .6rem;
    padding: 0 .2rem;
    margin-right: .3rem;
  }
  p{
  @include sc(.6rem, #777);
  }
  }
  }
  }
  #out_delivery{
  .out_header{
  @include sc(.6rem, #666);
    line-height: 1.5rem;
    padding-left: .5rem;
    background-color: #f5f5f5;
  }
  *{
    color: #ccc;
  }
  }
  .router-slid-enter-active, .router-slid-leave-active {
    transition: all .4s;
  }
  .router-slid-enter, .router-slid-leave-active {
    transform: translate3d(2rem, 0, 0);
    opacity: 0;
  }
</style>
